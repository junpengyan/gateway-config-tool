#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
PORT_ARG="${PORT:-8765}"
python3 launcher.py stop --port "$PORT_ARG" "$@"
