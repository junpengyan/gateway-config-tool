io-config-tool - macos source package

Requires Python 3.10 or newer. This is a Python source package, not a native executable.
Unzip first; run start.bat on Windows or start.command / ./start.sh on macOS.
The service binds to 127.0.0.1; see README.md for the default port.
The data directory is created at first launch. Existing plans, generated projects,
logs, PID files and credentials are intentionally excluded. Back them up separately.
For gateway-config-tool-v2, supply template db.xml / CSV files and update their
paths in the UI after moving to a different machine.
