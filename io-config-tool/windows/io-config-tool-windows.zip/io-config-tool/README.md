# 采集服务配置生成工具 v14

## 版本说明

基于 Codex 初版 README 中描述的完整能力进行补齐，重点恢复并完善：模板多次/多选导入、BMS/GROUPBMS/CELL 分段识别、设备清单自动补齐、DS 每组设备计算、MQTT 转发完整参数、104 采集/转发参数、Tag 参数规则覆盖、配置快照导入导出。

## 启动

### Windows PowerShell

```powershell
.\start.bat --port 8888
```

访问：

```text
http://127.0.0.1:8888
```

停止：

```powershell
.\stop.bat --port 8888
```

查看状态：

```powershell
.\status.bat --port 8888
```

### Linux

```bash
chmod +x start.sh stop.sh status.sh
./start.sh --port 8888
./status.sh --port 8888
./stop.sh --port 8888
```

## 文件说明

| 文件 | 作用 |
| -- | -- |
| `app.py` | 本地 HTTP 服务入口 |
| `generator.py` | XML 生成逻辑 |
| `template_parser.py` | db.xml / CSV 模板解析逻辑 |
| `templates/index.html` | 工具页面 |
| `static/app.js` | 前端交互逻辑 |
| `static/style.css` | 页面样式 |
| `launcher.py` | 启动、停止、状态检查管理器 |
| `start.bat` / `stop.bat` / `status.bat` | Windows 批处理入口 |
| `start.ps1` / `stop.ps1` / `status.ps1` | PowerShell 入口 |
| `start.sh` / `stop.sh` / `status.sh` | Linux 入口 |

## 功能说明

### 1. 模板导入

支持导入：

- `db.xml`：从 `<io>` 中提取采集通道、设备、tags 模板。
- 采集通道 `.csv`：按列 `点名(英文)`、`点描述(中文)`、`采集周期`、`单位`、`s0`、`s1`、`s2` 生成 tags 模板。

支持多选导入、重复导入和分批导入。新导入同类型模板会覆盖旧模板，其他类型会合并保留。

### 2. 设备清单自动补齐

导入 db.xml 后，工具会从 `<channel>`、`<device><cnfg desc="...">` 和 tags 描述中识别设备类型和设备实例，并自动补齐设备清单。

例如识别到 `bms62`、`bms63`、`bms64`，会压缩为：

```text
类型=BMS，设备前缀=bms，起始编号=62，数量=3
```

若编号不连续，会拆成多行显示。

### 3. BMS / GROUPBMS / CELL 分段

如果 BMS 模板中包含：

- `BMS_`
- `GroupBMS_`
- `Cell_`

工具会自动统计分段点数，并在设备清单中补出：

- `BMS`
- `GROUPBMS`
- `CELL`

其中：

- `BMS` 行的单设备点数只显示 BMS_ 段点数。
- `GROUPBMS` / `CELL` 行用于配置 DS 分组，不生成采集服务 `<io>` 通道。
- 生成采集服务 `<io>` 时，BMS 通道仍写入完整 BMS 模板全部 tags。

### 4. 采集服务配置

在“基础配置”中选择采集服务类型：

- 仿真驱动：生成 `TN_SIMULATOR` 采集通道。
- 104规约：生成 `ELE_IEC_104` 采集通道。

选择 104 采集后，可填写：

- `104采集设备类型`：留空表示全部类型使用 104；也可填写 `PCS`，多个类型用逗号分隔。
- `104采集IP`
- `104采集起始端口`

### 5. 转发通道 DS

在“转发通道 DS”中选择转发服务类型：

- MQTT：生成 `MQTT_DZ_XJX` 转发通道。
- 104规约：生成 `ELE_IEC_104` 转发通道。

MQTT 模式保留完整客户端参数：

- ip
- port
- clientid
- user
- pwd
- sn
- qos
- pub
- sub
- pub2
- change
- pub_timer
- cmd
- log
- time
- ifcache
- hispath
- capacity
- sendhis

104 转发模式会生成 104 转发端口和参数，并按点描述后缀区分：

- `_YX`：遥信
- `_YC`：遥测
- `_YT`：遥调/遥控

### 6. DS 每组设备

设备清单中显示 `DS每组设备`，根据以下公式自动计算：

```text
min(设备数量, floor(转发通道最大标签数 / 单设备点数))
```

DS 分组生成会保证：

```text
每组设备数 × 该类型每台点数 <= 转发通道最大标签数
```

### 7. 点位与参数规则

支持手动粘贴点位清单 CSV：

```text
类型,Tag名,描述,周期,s0,s1,s2
BMS,Tag1,BMS_RunningState_YC,1000,4,,
```

支持 Tag 参数规则 CSV：

```text
类型,起始Tag,结束Tag,参数1,参数2,参数3,采集周期
BMS,Tag1,Tag10,4,,,1000
*,Tag1,Tag5,1,20,10,1000
```

规则支持 `*` 通配所有类型，并且优先级高于导入模板和占位参数。

### 8. 生成和下载

点击“生成 XML”后，右侧会显示：

- 汇总校验
- 分通道方案
- 模板识别结果
- XML 结果

点击“下载 XML”即可下载生成文件。

## 常见问题

### 1. 导入模板后设备清单没有变化

请确认 db.xml 中的 `<io>` 下存在 `<channel>`、`<devices>`、`<device>`、`<tags>`，并且通道描述、设备描述或点描述中能识别 BMS / PCS / BOX / CL。

### 2. 只想 PCS 使用 104 采集怎么办

基础配置选择“104规约”，然后在 `104采集设备类型` 填写：

```text
PCS
```

### 3. BMS 模板里有 Cell 点，为什么采集服务没有单独生成 CELL 通道

这是正常逻辑。CELL / GROUPBMS 行只用于 DS 分组，采集服务仍只生成 BMS 通道，Cell 和 GroupBMS 点位来自 BMS 设备 tags。

### 4. Python 3.13 能否使用

可以。工具不再使用 Python 3.13 已移除的 `cgi` 模块。

## v9-v12 更新：转发通道发布周期配置

转发通道 DS 中新增“转发通道发布周期”配置表，可对 MQTT 转发通道分别配置：

- 变化周期：生成到 MQTT 参数 `change`，例如页面填写 `3`，生成 `<p name="change" value="3" />`，表示 3 秒一变化。
- 全部数据发布周期：生成到 MQTT 参数 `pub_timer`，例如页面填写 `300`，生成 `<p name="pub_timer" value="300" />`。

说明：`change` 和 `pub_timer` 都是可输入的数字，允许填写 0；填写 0 时会原样生成到 db 文件，不再被默认值覆盖。`time` 参数保持默认 `60`，不作为“全部数据发布周期”的配置项。

匹配对象支持以下写法：

| 匹配对象 | 说明 |
| -- | -- |
| `*` | 默认规则，未命中其他规则时使用 |
| `bms`、`pcs`、`box`、`groupbms`、`cell`、`cl` | 按转发通道类型配置 |
| `C1`、`C2` | 按生成后的转发通道名配置 |
| `bms62-66`、`pcs62-66` | 按生成后的转发通道描述配置 |

规则优先级：表格中靠后的规则优先级更高。因此可以先配置 `*` 默认值，再增加 `bms`、`pcs` 或 `C1` 做精确覆盖。

该配置只影响 MQTT 转发服务参数；选择 104 规约转发时不会输出 MQTT 的 `change` 和 `pub_timer` 参数。


## v10 修复说明

- 修复“转发通道发布周期”中的“添加规则”按钮在部分页面状态下点击无响应的问题。
- 新增规则会直接追加到表格末尾、自动聚焦匹配对象输入框，并使用浅色背景提示新增行。
- 发布周期规则删除按钮改为独立按钮事件，不再和设备清单删除逻辑混用。


## v11-v12 修复说明

- v11 曾把 `change` 做成 0/1 开关，不符合铁牛加载后的实际周期含义。
- v12 已改为：页面“变化周期”直接写入 `<p name="change" value="周期" />`，例如填写 0 就生成 `change=0`。
- 页面“全部数据发布周期”直接写入 `<p name="pub_timer" value="周期" />`。
- 兼容旧配置：旧字段 `changeValue`、`change`、`changeEnable` 会作为变化周期读取；旧字段 `fullPeriod` 会按新的 `pub_timer` 处理。


## v14 修复说明：单设备类型不追加序号

当某一类转发设备只有 1 个时，MQTT 转发通道的描述和客户端凭据不再追加 `1` 或 `z1`。

示例：策略设备 `CL` 只有 1 个，且凭据前缀为 `jd` 时：

```xml
<cnfg name="C1" desc="cl" plugin="MQTT_DZ_XJX">
  ...
  <p name="clientid" value="jd-cl" />
  <p name="user" value="jd-cl" />
  <p name="pwd" value="jd-cl" />
</cnfg>
```

如果该类型设备数量大于 1，则仍保持原有批量递增规则，例如：

```text
cl1-2 / jd-clz1
```

该规则适用于 MQTT 转发通道中的 `bms`、`pcs`、`box`、`cl`、`groupbms`、`cell` 等类型。
## v15 更新说明：兼容自研网关工程文件

基础配置中新增“工程文件格式”：

| 格式 | 输出文件 | 使用场景 |
| -- | -- | -- |
| 铁牛 db.xml | `db.generated.xml` | 继续导入铁牛 TnBuild 工具使用 |
| 自研网关 tb_gateway.json | `tb_gateway.generated.json` | 导入公司自研网关工程使用 |

自研网关格式会生成：

- `project_name`：来自页面“网关工程名称”。
- `corridors_eq`：采集通道，按当前设备清单生成，通道类型为 `simulate_enhanced`。
- `corridors_zf`：转发通道，复用当前 DS 分组规则和 MQTT 参数。

字段映射要点：

- 采集点位会转换为网关 `point_table`，并自动增加 `device_status`。
- 铁牛 tag 的 `s0` 映射到网关 `generator_type`。
- 铁牛 tag 的 `s2` 映射到网关 `var1`，`s1` 映射到网关 `var2`。
- 转发点位的 `point_key_in` 对应采集点路径，例如 `C1.D1.Tag1`。
- `customize_info` 按转发设备类型写入，例如 `bms1`、`cell1`、`groupbms1`。
- MQTT 的 `client_id`、`user_name`、`pass_word` 会按转发通道对应设备类型生成，避免 cell 通道使用 bms 凭据。
