﻿const $ = (id) => document.getElementById(id);
const fields = ["projectFormat","gatewayProjectName","collectProtocol","outputMode","rootVer","maxTags","channelStart","deviceName","pluginName","io104Types","io104Host","io104PortStart","fallbackPeriod","fallbackS0","generateDs","maxDsTags","dsPluginName","dsChannelDesc","dsProtocol","ds104Host","ds104PortStart","mqttQos","mqttHost","mqttPort","mqttCredentialPrefix","mqttSn","mqttPub","mqttSub","mqttPub2","manualTemplates","tagParamRules"];
let templates = {};
let lastArtifact = "";
let lastArtifactName = "db.generated.xml";
let lastArtifactMime = "text/xml;charset=utf-8";
const presetDevices = [
  {type:"BMS",prefix:"bms",startNo:62,count:61,points:1100},
  {type:"PCS",prefix:"pcs",startNo:62,count:61,points:295},
  {type:"BOX",prefix:"box",startNo:1,count:13,points:130},
];
const defaultDsPeriodRules = [
  {match:"*", changePeriod:"1", pubTimer:"300", note:"榛樿瑙勫垯"},
  {match:"bms", changePeriod:"1", pubTimer:"300", note:"BMS杞彂閫氶亾"},
  {match:"pcs", changePeriod:"1", pubTimer:"300", note:"PCS杞彂閫氶亾"},
  {match:"box", changePeriod:"1", pubTimer:"300", note:"BOX杞彂閫氶亾"},
  {match:"groupbms", changePeriod:"1", pubTimer:"300", note:"GroupBMS杞彂閫氶亾"},
  {match:"cell", changePeriod:"1", pubTimer:"300", note:"Cell杞彂閫氶亾"},
];
function esc(s){return String(s??"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;","'":"&#39;"}[m]));}
function msg(text,level=""){return `<div class="msg ${level}">${esc(text)}</div>`;}
function setVisible(selector, visible){document.querySelectorAll(selector).forEach(el=>el.classList.toggle("hidden",!visible));}
function applyProjectFormatMode(){
  const format=$("projectFormat")?.value || "ironbull";
  setVisible(".format-xml-only", format==="ironbull");
  if(format!=="ironbull" && $("outputMode")) $("outputMode").value="full";
}
function clearGeneratedArtifact(){
  lastArtifact="";
  lastArtifactName="db.generated.xml";
  lastArtifactMime="text/xml;charset=utf-8";
  if($("xmlOutput")) $("xmlOutput").value="";
}
function protocolInfo(){
  const collect=$("collectProtocol")?.value || "sim";
  const ds=$("dsProtocol")?.value || "mqtt";
  const collectText = collect==="iec104" ? "閲囬泦鏈嶅姟锛?04瑙勭害" : "閲囬泦鏈嶅姟锛氫豢鐪熼┍鍔?;
  const dsText = ds==="iec104" ? "杞彂鏈嶅姟锛?04瑙勭害" : "杞彂鏈嶅姟锛歁QTT";
  return {collect, ds, title:`${collectText}锛?{dsText}`};
}
function applyProtocolMode(){
  const p=protocolInfo();
  setVisible(".protocol-sim-collect",p.collect==="sim");
  setVisible(".protocol-104-collect",p.collect==="iec104");
  setVisible(".protocol-mqtt-ds",p.ds==="mqtt");
  setVisible(".protocol-104-ds",p.ds==="iec104");
  if($("dsModeText")){ $("dsModeText").textContent=p.ds==="mqtt"?"杞彂 MQTT":"杞彂 104瑙勭害"; $("dsModeText").className="pill ok"; }
  $("messages").innerHTML=msg(`褰撳墠閰嶇疆锛?{p.title}`,"ok");
  applyProjectFormatMode();
  updateDsGroupSizes();
}
function collectConfig(){const c={};fields.forEach(id=>c[id]=$(id)?.value??"");c.dsPeriodRules=readDsPeriodRules();return c;}
function setConfig(c){
  if(c.protocolMode && !c.collectProtocol){ c.collectProtocol=c.protocolMode==="iec104_mqtt"?"iec104":"sim"; }
  if(c.protocolMode && !c.dsProtocol){ c.dsProtocol=c.protocolMode==="sim_iec104"?"iec104":"mqtt"; }
  fields.forEach(id=>{if($(id)&&c[id]!==undefined)$(id).value=c[id];});
  renderDsPeriodRules(c.dsPeriodRules || defaultDsPeriodRules);
  applyProtocolMode();
}

function normalizePeriodNumber(value, fallback){
  const text = String(value ?? "").trim();
  if(!text) return String(fallback);
  const num = Number(text);
  return Number.isFinite(num) && num >= 0 ? text : String(fallback);
}
function normalizeDsPeriodRule(r={}){
  const changeRaw = r.changePeriod ?? r.changeValue ?? r.change ?? r.changeEnable ?? "1";
  const pubTimerRaw = r.pubTimer ?? r.pub_timer ?? r.fullPeriod ?? "300";
  return {
    match: r.match ?? "",
    changePeriod: normalizePeriodNumber(changeRaw, "1"),
    pubTimer: normalizePeriodNumber(pubTimerRaw, "300"),
    note: r.note ?? ""
  };
}
function readDsPeriodRules(){
  const rows=[...document.querySelectorAll("#dsPeriodRows tr")].map(tr=>({
    match:(tr.querySelector(".period-match")?.value || "").trim(),
    changePeriod:(tr.querySelector(".period-change")?.value || "1").trim(),
    pubTimer:(tr.querySelector(".period-pubtimer")?.value || "300").trim(),
    note:(tr.querySelector(".period-note")?.value || "").trim()
  })).filter(r=>r.match);
  return rows.length?rows:[...defaultDsPeriodRules];
}
function createDsPeriodRow(r={}, focus=false){
  r = normalizeDsPeriodRule(r);
  const tr=document.createElement("tr");
  tr.innerHTML=`
    <td><input class="device-input period-match" value="${esc(r.match ?? '')}" placeholder="* / bms / pcs / C1"></td>
    <td><input class="device-input period-change" type="number" min="0" step="any" value="${esc(r.changePeriod || '1')}" placeholder="濡?3"></td>
    <td><input class="device-input period-pubtimer" type="number" min="0" step="any" value="${esc(r.pubTimer || '300')}" placeholder="濡?300"></td>
    <td><input class="device-input period-note" value="${esc(r.note || '')}" placeholder="鍙€夎鏄?></td>
    <td><button type="button" class="link-danger period-remove">鍒犻櫎</button></td>
  `;
  if(focus){
    tr.classList.add("row-new");
    setTimeout(()=>{
      const input=tr.querySelector(".period-match");
      input?.focus();
      tr.scrollIntoView({block:"nearest",behavior:"smooth"});
    },0);
  }
  return tr;
}
function renderDsPeriodRules(rows=defaultDsPeriodRules){
  const target=$("dsPeriodRows");
  if(!target)return;
  target.innerHTML="";
  (rows&&rows.length?rows:defaultDsPeriodRules).forEach(r=>target.appendChild(createDsPeriodRow(r,false)));
}
function addDsPeriodRule(){
  const target=$("dsPeriodRows");
  if(!target)return;
  target.appendChild(createDsPeriodRow({match:"",changePeriod:"1",pubTimer:"300",note:""},true));
  const info=$("templateMessages");
  if(info)info.innerHTML=msg("宸叉柊澧炰竴鏉¤浆鍙戦€氶亾鍙戝竷鍛ㄦ湡瑙勫垯锛岃濉啓鍖归厤瀵硅薄銆?,"ok");
}
function removeDsPeriodRule(button){
  const tr=button.closest("tr");
  if(tr)tr.remove();
  if(!$("dsPeriodRows")?.children.length)renderDsPeriodRules(defaultDsPeriodRules);
}

function calcDsGroupSize(count, points){
  const limit=Math.max(1, Number($("maxDsTags")?.value || 6000));
  const safeCount=Math.max(1, Number(count || 1));
  const safePoints=Math.max(1, Number(points || 1));
  return Math.max(1, Math.min(safeCount, Math.floor(limit / safePoints)));
}
function readDevices(){return [...document.querySelectorAll("#deviceRows tr")].map(tr=>({type:tr.querySelector(".type").value.trim().toUpperCase(),prefix:tr.querySelector(".prefix").value.trim(),startNo:Number(tr.querySelector(".startNo").value||1),count:Number(tr.querySelector(".count").value||0),points:Number(tr.querySelector(".points").value||0)})).filter(x=>x.type&&x.prefix);}
function renderDevices(rows=presetDevices){
  $("deviceRows").innerHTML=rows.map((r,i)=>`<tr><td><input class="device-input type" value="${esc(r.type)}"></td><td><input class="device-input prefix" value="${esc(r.prefix)}"></td><td><input class="device-input startNo" type="number" value="${r.startNo}"></td><td><input class="device-input count" type="number" value="${r.count}"></td><td><input class="device-input points" type="number" value="${r.points}"></td><td><span class="pill ok ds-size">${calcDsGroupSize(r.count,r.points)}</span></td><td><span class="danger-text" data-i="${i}">鍒犻櫎</span></td></tr>`).join("");
  document.querySelectorAll(".danger-text").forEach(x=>x.onclick=()=>{x.closest("tr").remove();updateDsGroupSizes();});
  document.querySelectorAll("#deviceRows input").forEach(x=>x.oninput=updateDsGroupSizes);
  updateDsGroupSizes();
}
function updateDsGroupSizes(){
  document.querySelectorAll("#deviceRows tr").forEach(tr=>{
    const target=tr.querySelector(".ds-size");
    if(!target)return;
    target.textContent=calcDsGroupSize(tr.querySelector(".count")?.value, tr.querySelector(".points")?.value);
  });
}
function mergeImportedDevices(importedRows){
  if(!Array.isArray(importedRows)||!importedRows.length)return 0;
  const current=readDevices();
  const imported=importedRows.map(r=>({
    type:String(r.type||"").trim().toUpperCase(),
    prefix:String(r.prefix||String(r.type||"dev").toLowerCase()).trim(),
    startNo:Number(r.startNo||1),
    count:Number(r.count||1),
    points:Number(r.points||0)
  })).filter(r=>r.type&&r.prefix&&r.count>0);
  if(!imported.length)return 0;
  const isDefaultRows=current.length===presetDevices.length && current.every((r,i)=>
    r.type===presetDevices[i].type && r.prefix===presetDevices[i].prefix &&
    Number(r.startNo)===presetDevices[i].startNo && Number(r.count)===presetDevices[i].count && Number(r.points)===presetDevices[i].points
  );
  if(isDefaultRows){renderDevices(imported);return imported.length;}
  const next=[...current];
  imported.forEach(row=>{
    const idx=next.findIndex(x=>x.type===row.type && x.prefix===row.prefix && Number(x.startNo)===row.startNo);
    if(idx>=0) next[idx]=row;
    else next.push(row);
  });
  renderDevices(next);
  return imported.length;
}
function renderTemplates(){
  const keys=Object.keys(templates);
  $("templateStatus").className=`pill ${keys.length?"ok":"warn"}`;
  $("templateStatus").textContent=keys.length?`宸插鍏?${keys.length} 绫籤:"鏈鍏?;
  $("templateRows").innerHTML=keys.length?keys.map(k=>{const t=templates[k];return `<tr><td>${esc(k)}</td><td>${esc(t.sourceChannel||t.sourceDesc||"")}</td><td>${esc(t.tagCount||t.tags?.length||0)}</td><td>${esc(t.firstTag||"")}</td><td>${esc(t.lastTag||"")}</td></tr>`}).join(""):`<tr><td colspan="5">灏氭湭瀵煎叆妯℃澘</td></tr>`;
}
async function generate(){
  applyProtocolMode();
  const payload={config:collectConfig(),devices:readDevices(),templates};
  const res=await fetch("/api/generate",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(payload)});
  const data=await res.json();
  lastArtifact=data.artifact ?? data.xml ?? "";
  lastArtifactName=data.artifactName || "db.generated.xml";
  lastArtifactMime=data.artifactMime || "text/xml;charset=utf-8";
  $("xmlOutput").value=lastArtifact;
  const s=data.summary||{};
  $("totalDevices").textContent=s.totalDevices||0;
  $("totalTags").textContent=s.totalTags||0;
  $("totalChannels").textContent=s.totalChannels||0;
  $("maxChannelTags").textContent=s.maxChannelTags||0;
  $("planRows").innerHTML=(data.plan||[]).length?(data.plan||[]).slice(0,300).map(p=>`<tr><td>${esc(p.channelName)}</td><td>${esc(p.channelDesc)}</td><td>${esc(p.channelTags)}</td></tr>`).join(""):`<tr><td colspan="3">鏆傛棤鏂规</td></tr>`;
  $("messages").innerHTML=(data.messages||[]).map(m=>msg(m.text,m.level)).join("")||msg("鏆傛棤鏍￠獙娑堟伅");
  $("overallStatus").className=`pill ${data.ok?"ok":"bad"}`;
  $("overallStatus").textContent=data.ok?"鐢熸垚鎴愬姛":"瀛樺湪閿欒";
}
async function parseTemplate(file){
  const fd=new FormData();fd.append("file",file);
  const res=await fetch("/api/parse-template",{method:"POST",body:fd});
  const data=await res.json();
  if(!data.ok)throw new Error(`${file.name}锛?{data.message||"妯℃澘瑙ｆ瀽澶辫触"}`);
  const importedTemplates=data.templates||{};
  const overwritten=Object.keys(importedTemplates).filter(k=>templates[k]);
  templates={...templates,...importedTemplates};
  const importedDeviceCount=mergeImportedDevices(data.devices||[]);
  renderTemplates();
  return {templateTypes:Object.keys(importedTemplates), overwritten, importedDeviceCount};
}
async function parseTemplateFiles(files){
  const list=[...files];
  if(!list.length)return;
  const messages=[];
  try{
    for(const file of list){
      const result=await parseTemplate(file);
      messages.push(msg(`${file.name} 瀵煎叆鎴愬姛锛?{result.templateTypes.join("銆?)||"鏃?}锛涙洿鏂拌澶囨竻鍗?${result.importedDeviceCount} 琛屻€俙,"ok"));
      if(result.overwritten.length)messages.push(msg(`${file.name} 瑕嗙洊宸叉湁妯℃澘锛?{result.overwritten.join("銆?)}`,"warn"));
    }
    $("templateMessages").innerHTML=messages.join("");
  }catch(err){
    $("templateMessages").innerHTML=messages.join("")+msg(err.message,"bad");
  }
}
function download(name,content,type="text/plain;charset=utf-8"){const blob=new Blob([content],{type});const url=URL.createObjectURL(blob);const a=document.createElement("a");a.href=url;a.download=name;document.body.appendChild(a);a.click();a.remove();URL.revokeObjectURL(url);}
function exportConfig(){download("io-config-snapshot.json",JSON.stringify({config:collectConfig(),devices:readDevices(),templates},null,2),"application/json;charset=utf-8");}
function importConfig(file){const r=new FileReader();r.onload=()=>{try{const data=JSON.parse(r.result);setConfig(data.config||{});renderDevices(data.devices||presetDevices);templates=data.templates||{};renderTemplates();$("templateMessages").innerHTML=msg("閰嶇疆蹇収宸插鍏ャ€?,"ok");}catch(e){alert(e.message)}};r.readAsText(file,"utf-8");}
$("btnGenerate").onclick=generate;
$("collectProtocol").onchange=applyProtocolMode;
$("projectFormat").onchange=()=>{applyProjectFormatMode();clearGeneratedArtifact();};
$("dsProtocol").onchange=applyProtocolMode;
$("generateDs").onchange=applyProtocolMode;
$("maxDsTags").oninput=updateDsGroupSizes;
$("btnAddDevice").onclick=()=>{const rows=readDevices();rows.push({type:"NEW",prefix:"dev",startNo:1,count:1,points:100});renderDevices(rows);};
$("btnPreset").onclick=()=>renderDevices(presetDevices);


document.addEventListener("click", (event)=>{
  const addButton=event.target.closest("#btnAddDsPeriod");
  if(addButton){
    event.preventDefault();
    addDsPeriodRule();
    return;
  }
  const removeButton=event.target.closest(".period-remove");
  if(removeButton){
    event.preventDefault();
    removeDsPeriodRule(removeButton);
  }
});

$("templateFile").onchange=async e=>{await parseTemplateFiles(e.target.files);e.target.value="";};
$("btnDownload").onclick=()=>{if(!lastArtifact.trim()){alert("请先生成工程文件");return;}download(lastArtifactName,lastArtifact,lastArtifactMime);};
$("btnCopy").onclick=async()=>{const txt=$("xmlOutput").value;if(!txt.trim())return;try{await navigator.clipboard.writeText(txt);alert("宸插鍒?);}catch{$("xmlOutput").select();document.execCommand("copy");alert("宸插鍒?);}};
$("btnExportConfig").onclick=exportConfig;
$("btnImportConfig").onclick=()=>$("configFile").click();
$("configFile").onchange=e=>{const f=e.target.files[0];if(f)importConfig(f);e.target.value="";};
renderDevices();renderTemplates();renderDsPeriodRules(defaultDsPeriodRules);applyProtocolMode();
