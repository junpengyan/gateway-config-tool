from __future__ import annotations

import json
import os
import sys
import threading
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse
from email.parser import BytesParser
from email.policy import default

from generator import generate
from template_parser import parse_template

BASE = Path(__file__).resolve().parent
PORT = int(os.environ.get("PORT", "8888"))
HOST = os.environ.get("HOST", "10.8.8.240")
DATA_DIR = BASE / "data"
DATA_DIR.mkdir(exist_ok=True)
PID_FILE = DATA_DIR / "io-config-tool.pid"


class Handler(SimpleHTTPRequestHandler):
    server_version = "IoConfigTool/1.0"

    def translate_path(self, path: str) -> str:
        path = urlparse(path).path
        if path == "/":
            return str(BASE / "templates" / "index.html")
        if path.startswith("/static/"):
            return str(BASE / path.lstrip("/"))
        return str(BASE / "templates" / "index.html")

    def send_json(self, obj, code: int = 200):
        data = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def read_body(self) -> bytes:
        length = int(self.headers.get("Content-Length", "0"))
        return self.rfile.read(length) if length > 0 else b""

    def read_json(self):
        raw = self.read_body()
        if not raw:
            return {}
        return json.loads(raw.decode("utf-8"))

    def read_multipart_file(self):
        content_type = self.headers.get("Content-Type", "")
        raw = self.read_body()
        if not raw:
            return None, b""
        # Python 3.13 removed cgi.FieldStorage. Use email parser from stdlib instead.
        msg = BytesParser(policy=default).parsebytes(
            f"Content-Type: {content_type}\r\nMIME-Version: 1.0\r\n\r\n".encode("utf-8") + raw
        )
        if not msg.is_multipart():
            return None, b""
        for part in msg.iter_parts():
            disposition = part.get_content_disposition()
            if disposition != "form-data":
                continue
            if part.get_param("name", header="content-disposition") != "file":
                continue
            filename = part.get_filename() or "template"
            payload = part.get_payload(decode=True) or b""
            return filename, payload
        return None, b""

    def do_GET(self):
        if self.path.startswith("/api/health"):
            return self.send_json({"ok": True, "name": "io-config-tool", "port": PORT})
        return super().do_GET()

    def do_POST(self):
        parsed = urlparse(self.path)
        try:
            if parsed.path == "/api/generate":
                payload = self.read_json()
                result = generate(payload.get("config", {}), payload.get("devices", []), payload.get("templates", {}))
                return self.send_json(result)
            if parsed.path == "/api/parse-template":
                filename, data = self.read_multipart_file()
                if not filename or not data:
                    return self.send_json({"ok": False, "message": "未接收到模板文件。"}, 400)
                parsed_template = parse_template(data, filename)
                # Backward compatible response shape. New parser returns both templates and discovered devices.
                if isinstance(parsed_template, dict) and "templates" in parsed_template:
                    templates = parsed_template.get("templates", {})
                    devices = parsed_template.get("devices", [])
                else:
                    templates = parsed_template
                    devices = []
                return self.send_json({"ok": True, "templates": templates, "devices": devices})
            if parsed.path == "/api/shutdown":
                self.send_json({"ok": True, "message": "服务正在停止。"})
                threading.Thread(target=self.server.shutdown, daemon=True).start()
                return
            return self.send_json({"ok": False, "message": "未知接口。"}, 404)
        except Exception as e:
            return self.send_json({"ok": False, "message": str(e)}, 500)


def main():
    PID_FILE.write_text(str(os.getpid()), encoding="utf-8")
    httpd = ThreadingHTTPServer((HOST, PORT), Handler)
    print(f"采集服务配置生成工具已启动: http://{HOST}:{PORT}")
    print(f"PID: {os.getpid()}")
    try:
        httpd.serve_forever()
    finally:
        try:
            PID_FILE.unlink(missing_ok=True)
        except Exception:
            pass
        print("服务已停止。")


if __name__ == "__main__":
    main()
