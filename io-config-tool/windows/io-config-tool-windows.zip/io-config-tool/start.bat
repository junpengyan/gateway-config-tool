@echo off
setlocal
cd /d "%~dp0"
set "ARGS=%*"
where python >nul 2>nul
if %errorlevel%==0 (
  python launcher.py start %ARGS%
  set "RC=%errorlevel%"
) else (
  where py >nul 2>nul
  if %errorlevel%==0 (
    py -3 launcher.py start %ARGS%
    set "RC=%errorlevel%"
  ) else (
    echo Python was not found. Please install Python 3 or add it to PATH.
    set "RC=1"
  )
)
echo.
if not "%RC%"=="0" echo Start failed. Run status.bat or check data\server.err.log.
pause
exit /b %RC%
