from __future__ import annotations

import argparse
import json
import os
import signal
import socket
import subprocess
import sys
import time
import urllib.request
from pathlib import Path

BASE = Path(__file__).resolve().parent
DATA = BASE / "data"
PID_FILE = DATA / "io-config-tool.pid"
LOG_FILE = DATA / "server.log"
ERR_FILE = DATA / "server.err.log"


def ensure_data():
    DATA.mkdir(exist_ok=True)


def read_pid() -> int | None:
    try:
        text = PID_FILE.read_text(encoding="utf-8").strip()
        return int(text) if text else None
    except Exception:
        return None


def is_pid_running(pid: int) -> bool:
    if pid <= 0:
        return False
    try:
        if os.name == "nt":
            result = subprocess.run(["tasklist", "/FI", f"PID eq {pid}", "/FO", "CSV", "/NH"],
                                    stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, text=True, encoding="utf-8", errors="ignore")
            return str(pid) in result.stdout
        os.kill(pid, 0)
        return True
    except Exception:
        return False


def url(port: int, host: str = "127.0.0.1") -> str:
    return f"http://{host}:{port}"


def health(port: int, host: str = "127.0.0.1", timeout: float = 1.0) -> bool:
    try:
        with urllib.request.urlopen(f"{url(port, host)}/api/health", timeout=timeout) as resp:
            return resp.status == 200
    except Exception:
        return False


def port_in_use(port: int, host: str = "127.0.0.1") -> bool:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.settimeout(0.5)
        return s.connect_ex((host, port)) == 0


def wait_for_health(port: int, host: str, seconds: int = 10) -> bool:
    deadline = time.time() + seconds
    while time.time() < deadline:
        if health(port, host, timeout=1):
            return True
        time.sleep(0.5)
    return False


def tail(path: Path, max_chars: int = 3000) -> str:
    if not path.exists():
        return ""
    try:
        data = path.read_text(encoding="utf-8", errors="ignore")
        return data[-max_chars:]
    except Exception:
        return ""


def start(args) -> int:
    ensure_data()
    port = int(args.port or os.environ.get("PORT", "8765"))
    host = args.host or os.environ.get("HOST", "127.0.0.1")

    old_pid = read_pid()
    if old_pid and is_pid_running(old_pid):
        if health(port, host):
            print(f"io-config-tool is already running. Open: {url(port, host)}")
            print(f"PID: {old_pid}")
            return 0
        print(f"Found old PID {old_pid}, but health check failed. You can run stop.bat, then start again.")

    if port_in_use(port, host) and not health(port, host):
        print(f"Port {port} is already in use by another process.")
        print("Change port, for example: start.bat --port 8888")
        return 2

    env = os.environ.copy()
    env["PORT"] = str(port)
    env["HOST"] = host

    LOG_FILE.write_text("", encoding="utf-8")
    ERR_FILE.write_text("", encoding="utf-8")
    stdout = LOG_FILE.open("ab")
    stderr = ERR_FILE.open("ab")
    cmd = [sys.executable, str(BASE / "app.py")]
    kwargs = {"cwd": str(BASE), "env": env, "stdout": stdout, "stderr": stderr, "stdin": subprocess.DEVNULL}
    if os.name == "nt":
        kwargs["creationflags"] = subprocess.CREATE_NEW_PROCESS_GROUP | subprocess.DETACHED_PROCESS
    else:
        kwargs["start_new_session"] = True

    print(f"Starting io-config-tool on port {port} ...")
    proc = subprocess.Popen(cmd, **kwargs)
    time.sleep(0.5)
    if proc.poll() is not None:
        print("Start failed. Python process exited immediately.")
        err = tail(ERR_FILE) or tail(LOG_FILE)
        if err:
            print("----- log -----")
            print(err)
        return 1

    if wait_for_health(port, host, seconds=args.wait):
        print(f"Started successfully. Open: {url(port, host)}")
        print(f"PID: {proc.pid}")
        print(f"Log file: {LOG_FILE}")
        return 0

    print("Start command was issued, but health check did not pass.")
    print(f"Try opening: {url(port, host)}")
    print(f"Check log: {LOG_FILE}")
    print(f"Check error log: {ERR_FILE}")
    err = tail(ERR_FILE) or tail(LOG_FILE)
    if err:
        print("----- latest log -----")
        print(err)
    return 3


def stop(args) -> int:
    ensure_data()
    port = int(args.port or os.environ.get("PORT", "8765"))
    host = args.host or os.environ.get("HOST", "127.0.0.1")
    stopped = False

    if health(port, host):
        try:
            req = urllib.request.Request(f"{url(port, host)}/api/shutdown", method="POST", data=b"{}", headers={"Content-Type": "application/json"})
            urllib.request.urlopen(req, timeout=2).read()
            stopped = True
            time.sleep(1)
        except Exception:
            pass

    pid = read_pid()
    if pid and is_pid_running(pid):
        try:
            if os.name == "nt":
                subprocess.run(["taskkill", "/PID", str(pid), "/F"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            else:
                os.kill(pid, signal.SIGTERM)
            stopped = True
        except Exception:
            pass

    try:
        PID_FILE.unlink(missing_ok=True)
    except Exception:
        pass

    if stopped:
        print("Stopped io-config-tool.")
        return 0
    print("io-config-tool was not running, or no matching process was found.")
    return 0


def status(args) -> int:
    ensure_data()
    port = int(args.port or os.environ.get("PORT", "8765"))
    host = args.host or os.environ.get("HOST", "127.0.0.1")
    pid = read_pid()
    ok = health(port, host)
    print(f"URL: {url(port, host)}")
    print(f"PID file: {pid if pid else 'not found'}")
    print(f"PID running: {is_pid_running(pid) if pid else False}")
    print(f"Health check: {'OK' if ok else 'FAILED'}")
    print(f"Log file: {LOG_FILE}")
    print(f"Error log: {ERR_FILE}")
    if not ok:
        err = tail(ERR_FILE) or tail(LOG_FILE)
        if err:
            print("----- latest log -----")
            print(err)
    return 0 if ok else 1


def main() -> int:
    parser = argparse.ArgumentParser(description="io-config-tool service manager")
    sub = parser.add_subparsers(dest="command", required=True)
    for name in ("start", "stop", "status"):
        p = sub.add_parser(name)
        p.add_argument("--port", type=int, default=None)
        p.add_argument("--host", default=None)
        if name == "start":
            p.add_argument("--wait", type=int, default=10)
    args = parser.parse_args()
    if args.command == "start":
        return start(args)
    if args.command == "stop":
        return stop(args)
    if args.command == "status":
        return status(args)
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
