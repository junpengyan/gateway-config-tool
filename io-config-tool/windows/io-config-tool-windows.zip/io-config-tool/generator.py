from __future__ import annotations

import csv
import html
import json
import re
from io import StringIO
from typing import Any, Dict, List, Tuple


def esc(value: Any) -> str:
    return html.escape(str(value if value is not None else ""), quote=True).replace("'", "&apos;")


def to_int(value: Any, default: int = 0) -> int:
    try:
        return int(str(value).strip())
    except Exception:
        return default


def split_csv_text(text: str) -> List[List[str]]:
    return [row for row in csv.reader(StringIO(text or "")) if any(str(c).strip() for c in row)]


def tag_no(value: str) -> int:
    matches = re.findall(r"\d+", str(value or ""))
    return int(matches[-1]) if matches else 0


def resolve_protocols(config: Dict[str, Any]) -> Dict[str, str]:
    collect = str(config.get("collectProtocol") or "sim").strip().lower()
    ds = str(config.get("dsProtocol") or "mqtt").strip().lower()
    if collect not in {"sim", "iec104"}:
        collect = "sim"
    if ds not in {"mqtt", "iec104"}:
        ds = "mqtt"
    collect_label = "采集服务：104规约" if collect == "iec104" else "采集服务：仿真驱动"
    ds_label = "转发服务：104规约" if ds == "iec104" else "转发服务：MQTT"
    return {"collect": collect, "ds": ds, "label": f"{collect_label}；{ds_label}"}


def parse_type_list(text: str) -> List[str]:
    return [x.strip().upper() for x in re.split(r"[,，\s]+", str(text or "")) if x.strip()]


def use_104_for_type(config: Dict[str, Any], t: str) -> bool:
    if resolve_protocols(config)["collect"] != "iec104":
        return False
    types = parse_type_list(config.get("io104Types", ""))
    return not types or "*" in types or str(t or "").upper() in types


def is_ds_only_type(t: str) -> bool:
    return str(t or "").upper() in {"CELL", "GROUPBMS"}


def validate_host(value: str, name: str, messages: List[Dict[str, str]]):
    if not str(value or "").strip():
        messages.append({"level": "bad", "text": f"{name} 不能为空。"})


def validate_port(value: Any, name: str, messages: List[Dict[str, str]]) -> int:
    port = to_int(value, 0)
    if port < 1 or port > 65535:
        messages.append({"level": "bad", "text": f"{name} 必须在 1-65535 之间。"})
    return port


def parse_manual_templates(text: str) -> Dict[str, List[Dict[str, str]]]:
    rows = split_csv_text(text)
    result: Dict[str, List[Dict[str, str]]] = {}
    for row in rows:
        row = [c.strip() for c in row]
        if not row or row[0].startswith("#") or row[0].lower() == "类型":
            continue
        if len(row) < 3:
            continue
        row += [""] * (7 - len(row))
        type_raw, tag_name, desc, period, s0, s1, s2 = row[:7]
        t = type_raw.upper()
        if not t or not tag_name or not desc:
            continue
        result.setdefault(t, []).append({
            "v": "1", "n": tag_name, "d": desc, "r": "0", "p": period or "1000",
            "u": "", "s0": s0, "s1": s1, "s2": s2,
        })
    return result


def parse_tag_rules(text: str) -> List[Dict[str, Any]]:
    rows = split_csv_text(text)
    rules: List[Dict[str, Any]] = []
    for row in rows:
        row = [c.strip() for c in row]
        if not row or row[0].startswith("#") or row[0].lower() == "类型":
            continue
        if len(row) < 6:
            continue
        row += [""] * (7 - len(row))
        type_raw, start_raw, end_raw, s0, s1, s2, period = row[:7]
        start = tag_no(start_raw)
        end = tag_no(end_raw or start_raw)
        if not start or not end:
            continue
        rules.append({"type": (type_raw or "*").upper(), "start": min(start, end), "end": max(start, end), "s0": s0, "s1": s1, "s2": s2, "period": period})
    return rules


def apply_rules(t: str, tags: List[Dict[str, str]], rules: List[Dict[str, Any]]) -> List[Dict[str, str]]:
    if not rules:
        return tags
    nt = str(t or "").upper()
    out = []
    for tag in tags:
        no = tag_no(tag.get("n", ""))
        matched = [r for r in rules if (r["type"] == "*" or r["type"] == nt) and r["start"] <= no <= r["end"]]
        if not matched:
            out.append(tag)
            continue
        r = matched[-1]
        ntg = dict(tag)
        ntg["s0"] = r["s0"]
        ntg["s1"] = r["s1"]
        ntg["s2"] = r["s2"]
        if r["period"]:
            ntg["p"] = r["period"]
        out.append(ntg)
    return out


def tag_xml(tag: Dict[str, Any]) -> str:
    keys = ["v", "n", "d", "r", "p", "u", "s0", "s1", "s2", "s3", "s4", "l"]
    attrs = [f'{k}="{esc(tag.get(k, ""))}"' for k in keys if k in tag]
    return f"<t {' '.join(attrs)} />"


def get_template_tags(templates: Dict[str, Any], t: str) -> List[Dict[str, str]]:
    tpl = templates.get(str(t or "").upper())
    if not tpl:
        return []
    return [dict(x) for x in (tpl.get("tags") or []) if isinstance(x, dict)]


def bms_segments(tags: List[Dict[str, str]]) -> Dict[str, int]:
    res = {"bms": 0, "groupbms": 0, "cell": 0}
    for tag in tags:
        d = tag.get("d", "")
        if re.match(r"^GroupBMS_", d or "", re.I):
            res["groupbms"] += 1
        elif re.match(r"^Cell_", d or "", re.I):
            res["cell"] += 1
        else:
            res["bms"] += 1
    return res


def get_io_point_count(t: str, fallback: int, templates: Dict[str, Any], manual: Dict[str, List[Dict[str, str]]]) -> int:
    nt = str(t or "").upper()
    tags = get_template_tags(templates, nt)
    if tags:
        # BMS IO generation must still include BMS_/GroupBMS_/Cell_ all tags.
        return len(tags)
    if nt in manual and manual[nt]:
        return len(manual[nt])
    return max(0, fallback)


def ds_point_config(devices: List[Dict[str, Any]]) -> Dict[str, int]:
    config: Dict[str, int] = {}
    for row in devices:
        t = str(row.get("type") or "").upper()
        points = max(0, to_int(row.get("points"), 0))
        if t == "BMS":
            config["bms"] = points
        elif t == "PCS":
            config["pcs"] = points
        elif t == "BOX":
            config["box"] = points
        elif t == "CL":
            config["cl"] = points
        elif t == "CELL":
            config["cell"] = points
        elif t == "GROUPBMS":
            config["groupbms"] = points
    return config


def ds_group_size_config(config: Dict[str, Any], devices: List[Dict[str, Any]]) -> Dict[str, int]:
    limit = max(1, to_int(config.get("maxDsTags"), 6000))
    result: Dict[str, int] = {}
    for row in devices:
        t = str(row.get("type") or "").upper()
        points = max(1, to_int(row.get("points"), 1))
        count = max(1, to_int(row.get("count"), 1))
        group_size = max(1, min(count, limit // points))
        if t == "BMS":
            result["bms"] = group_size
        elif t == "PCS":
            result["pcs"] = group_size
        elif t == "BOX":
            result["box"] = group_size
        elif t == "CL":
            result["cl"] = group_size
        elif t == "CELL":
            result["cell"] = group_size
        elif t == "GROUPBMS":
            result["groupbms"] = group_size
    return result


def fallback_tags(t: str, points: int, period: int, s0: str, ds_points: Dict[str, int] | None = None) -> List[Dict[str, str]]:
    nt = str(t or "").upper()
    rows: List[Dict[str, str]] = []
    segments = [(f"{nt}_Tag", points)]
    if nt == "BMS" and ds_points:
        group_count = min(points, ds_points.get("groupbms", 0))
        cell_count = min(max(0, points - group_count), ds_points.get("cell", 0))
        bms_count = max(0, points - group_count - cell_count)
        segments = [("BMS_Tag", bms_count), ("GroupBMS_Tag", group_count), ("Cell_Tag", cell_count)]
        segments = [x for x in segments if x[1] > 0]
    tag_index = 1
    for prefix, count in segments:
        for i in range(1, count + 1):
            rows.append({"v": "1", "n": f"Tag{tag_index}", "d": f"{prefix}{i}", "r": "0", "p": str(period), "u": "", "s0": s0, "s1": "", "s2": ""})
            tag_index += 1
    return rows


def get_tags(t: str, points: int, config: Dict[str, Any], templates: Dict[str, Any], manual: Dict[str, List[Dict[str, str]]], rules: List[Dict[str, Any]], ds_points: Dict[str, int]) -> List[Dict[str, str]]:
    nt = str(t or "").upper()
    tags = get_template_tags(templates, nt)
    if tags:
        return apply_rules(nt, tags, rules)
    if nt in manual and manual[nt]:
        return apply_rules(nt, manual[nt], rules)
    return apply_rules(nt, fallback_tags(nt, points, to_int(config.get("fallbackPeriod"), 1000), str(config.get("fallbackS0", "0")), ds_points), rules)


def build_plan(config: Dict[str, Any], devices: List[Dict[str, Any]], templates: Dict[str, Any], manual: Dict[str, List[Dict[str, str]]]) -> Tuple[List[Dict[str, Any]], List[Dict[str, str]]]:
    messages: List[Dict[str, str]] = []
    max_tags = max(1, to_int(config.get("maxTags"), 6000))
    channel_no = max(1, to_int(config.get("channelStart"), 1))
    ds_sizes = ds_group_size_config(config, devices)
    plan: List[Dict[str, Any]] = []
    for item in devices:
        t = str(item.get("type", "")).strip().upper()
        prefix = str(item.get("prefix", "")).strip()
        if not t or not prefix:
            continue
        if is_ds_only_type(t):
            messages.append({"level": "ok", "text": f"{t} 仅用于 DS 分组，不生成采集通道。"})
            continue
        count = max(0, to_int(item.get("count"), 0))
        start = max(1, to_int(item.get("startNo"), 1))
        fallback_points = max(0, to_int(item.get("points"), 0))
        io_points = get_io_point_count(t, fallback_points, templates, manual)
        if count <= 0 or io_points <= 0:
            messages.append({"level": "bad", "text": f"{t} 的设备数量或点数无效。"})
            continue
        if io_points > max_tags:
            messages.append({"level": "bad", "text": f"{t} 单设备 {io_points} 点，超过单通道上限 {max_tags}。当前版本不自动拆分单设备点位。"})
            continue
        cat = t.lower()
        for i in range(count):
            no = start + i
            plan.append({"type": t, "prefix": prefix, "channelName": f"C{channel_no}", "channelDesc": f"{prefix}{no}", "startNo": no, "endNo": no, "deviceCount": 1, "pointsPerDevice": io_points, "channelTags": io_points, "dsGroupSize": ds_sizes.get(cat, 1)})
            channel_no += 1
    return plan, messages


def build_104_collect_pars() -> List[str]:
    names = [("reson_len", "2"), ("address_len", "2"), ("body_len", "3"), ("t1", "15"), ("t2", "10"), ("t3", "20"), ("k", "12"), ("w", "8"), ("qcc", "5"), ("time1", "0"), ("time2", "15"), ("time3", "15"), ("dpi", "NO"), ("pym", "NO")]
    return ["          <pars>"] + [f'            <p name="{n}" value="{v}" />' for n, v in names] + ["          </pars>"]


def normalize_104_tag(tag: Dict[str, str], counters: Dict[str, int]) -> Dict[str, str]:
    if tag.get("s3"):
        return tag
    is_yx = re.search(r"_YX$", tag.get("d", ""), re.I)
    key = "yx" if is_yx else "yc"
    address = counters[key]
    counters[key] += 1
    out = dict(tag)
    out.update({"v": "1", "s0": "1", "s1": "0" if is_yx else "1", "s2": str(address), "s3": "0" if is_yx else "2"})
    return out


def ds_category(t: str, desc: str) -> str:
    nt = str(t or "").upper()
    if nt == "BMS" and re.match(r"^GroupBMS_", desc or "", re.I):
        return "groupbms"
    if nt == "BMS" and re.match(r"^Cell_", desc or "", re.I):
        return "cell"
    return nt.lower()


def ds_group_no(t: str, category: str, business_no: int, ordinal: int) -> int:
    return ordinal if str(t or "").upper() == "BMS" else business_no


def ds_sub_device(category: str, io_device_desc: str, ordinal: int) -> str:
    if category == "groupbms":
        return f"groupbms{ordinal}"
    if category == "cell":
        return f"cell{ordinal}"
    return io_device_desc


def point_value_type(desc: str) -> int:
    return 0 if re.search(r"_YX$", desc or "", re.I) else 1


def gateway_collect_point(tag: Dict[str, Any]) -> Dict[str, Any]:
    return {
        "tag": str(tag.get("n") or ""),
        "name": str(tag.get("d") or ""),
        "flag": True,
        "generator_type": to_int(tag.get("s0"), 0),
        "var1": str(tag.get("s2") or ""),
        "var2": str(tag.get("s1") or ""),
        "interval": to_int(tag.get("p"), 1000),
        "use_formula": False,
        "coefficient": 1.0,
        "offset": 0,
        "read_write": to_int(tag.get("r"), 0),
        "valueType": point_value_type(str(tag.get("d") or "")),
    }


def gateway_device_status_point() -> Dict[str, Any]:
    return {
        "tag": "device_status",
        "name": "设备状态",
        "flag": True,
        "generator_type": 0,
        "var1": "",
        "var2": "",
        "interval": 1000,
        "use_formula": False,
        "coefficient": 1.0,
        "offset": 0,
        "read_write": 0,
        "valueType": 0,
    }


def gateway_mqtt_server(config: Dict[str, Any], credential: str, periods: Dict[str, str], device: Dict[str, Any]) -> Dict[str, Any]:
    return {
        "mqtt_version": 4,
        "host": str(config.get("mqttHost") or "127.0.0.1"),
        "port": to_int(config.get("mqttPort"), 1883),
        "client_id": credential,
        "user_name": credential,
        "pass_word": credential,
        "sn_info": str(config.get("mqttSn") or "TN001"),
        "minPackSendDelayMS": 0,
        "qos": to_int(config.get("mqttQos"), 0),
        "storage_read_records_count": 1000,
        "cache_switch": False,
        "cache_path": "./cache",
        "max_cache_time": 24.0,
        "cache_send_delay": 1000,
        "change_check": to_int(periods.get("changePeriod"), 1),
        "send_data_topic": str(config.get("mqttPub") or "v1/devices/me/telemetry"),
        "rpc_topic": str(config.get("mqttSub") or "v1/devices/me/rpc/request/+"),
        "rpc_response_topic": "",
        "message_tool": "message_platform",
        "rpc_tool": "rpc_tool_platform",
        "devices": [device],
        "storage_max_records_count": 1000,
        "storage_type": "memory",
    }


def build_gateway_forward_corridors(config: Dict[str, Any], groups: List[Dict[str, Any]], max_ds_tags: int) -> List[Dict[str, Any]]:
    if str(config.get("generateDs", "yes")) != "yes":
        return []
    corridors: List[Dict[str, Any]] = []
    ds_limit = max(1, max_ds_tags)
    channel_idx = 1
    credential_counters: Dict[str, int] = {}
    categories: List[str] = []
    for group in groups:
        cat = str(group.get("category") or "dev")
        if cat not in categories:
            categories.append(cat)

    def make_corridor(category: str, category_group_count: int, bucket: List[Dict[str, Any]]) -> None:
        nonlocal channel_idx
        first_no = bucket[0].get("groupNo", 1)
        last_no = bucket[-1].get("groupNo", first_no)
        single_category_device = category_group_count == 1 and first_no == last_no
        channel_desc = category if single_category_device else f"{category}{first_no}-{last_no}" if first_no != last_no else f"{category}{first_no}"
        refs: List[Dict[str, Any]] = []
        for group in bucket:
            refs.extend(group.get("refs", []))
        point_table = [{
            "tag": str(ref.get("name") or ""),
            "name": str(ref.get("desc") or ""),
            "flag": True,
            "read_write": 0,
            "valueType": point_value_type(str(ref.get("tagDesc") or "")),
            "point_key_in": str(ref.get("name") or ""),
            "customize_info": str(ref.get("subDevice") or ""),
        } for ref in refs]
        credential_counters[category] = credential_counters.get(category, 0) + 1
        cred_prefix = str(config.get("mqttCredentialPrefix") or "client").rstrip("-")
        credential = f"{cred_prefix}-{category}" if single_category_device else f"{cred_prefix}-{category}z{credential_counters[category]}"
        periods = resolve_ds_periods(config, category, f"C{channel_idx}", channel_desc)
        device = {
            "change": to_int(periods.get("changePeriod"), 1),
            "interval": to_int(periods.get("pubTimer"), 300),
            "offset": 0,
            "point_table": point_table,
            "deviceName": f"C{channel_idx}",
            "alias_name": channel_desc,
            "used": True,
        }
        corridors.append({
            "name": f"C{channel_idx}",
            "alias_name": channel_desc,
            "used": True,
            "type": "mqtt",
            "server": gateway_mqtt_server(config, credential, periods, device),
        })
        channel_idx += 1

    for category in categories:
        cat_groups = [g for g in groups if str(g.get("category") or "dev") == category]
        category_group_count = len(cat_groups)
        bucket: List[Dict[str, Any]] = []
        bucket_tags = 0
        bucket_group_size = 0

        def flush() -> None:
            nonlocal bucket, bucket_tags, bucket_group_size
            if not bucket:
                return
            make_corridor(category, category_group_count, bucket)
            bucket = []
            bucket_tags = 0
            bucket_group_size = 0

        for group in cat_groups:
            refs = group.get("refs", [])
            configured_group_size = max(1, to_int(group.get("dsGroupSize"), 1))
            max_by_tags = max(1, ds_limit // max(1, len(refs)))
            group_size = min(configured_group_size, max_by_tags)
            if bucket and (bucket_tags + len(refs) > ds_limit or len(bucket) >= bucket_group_size or group_size != bucket_group_size):
                flush()
            bucket_group_size = group_size
            bucket.append(group)
            bucket_tags += len(refs)
            if bucket_tags >= ds_limit or len(bucket) >= bucket_group_size:
                flush()
        flush()
    return corridors


def build_gateway_project(config: Dict[str, Any], eq_corridors: List[Dict[str, Any]], ds_groups: List[Dict[str, Any]], max_ds_tags: int) -> Dict[str, Any]:
    return {
        "project_name": str(config.get("gatewayProjectName") or "工程1"),
        "corridors_eq": eq_corridors,
        "corridors_zf": build_gateway_forward_corridors(config, ds_groups, max_ds_tags),
    }


def generate(config: Dict[str, Any], devices: List[Dict[str, Any]], templates: Dict[str, Any] | None = None) -> Dict[str, Any]:
    templates = templates or {}
    messages: List[Dict[str, str]] = []
    protocols = resolve_protocols(config)
    messages.append({"level": "ok", "text": f"当前配置：{protocols['label']}。"})
    generate_ds = str(config.get("generateDs", "yes")) == "yes"

    if protocols["collect"] == "iec104":
        validate_port(config.get("io104PortStart", 2404), "104采集起始端口", messages)
        validate_host(config.get("io104Host", ""), "104采集IP", messages)
    else:
        if not str(config.get("pluginName") or "").strip():
            messages.append({"level": "bad", "text": "采集服务使用仿真驱动时，采集插件不能为空。"})

    if generate_ds and protocols["ds"] == "mqtt":
        validate_port(config.get("mqttPort", 1883), "MQTT服务器端口", messages)
        validate_host(config.get("mqttHost", ""), "MQTT服务器IP", messages)
        qos = to_int(config.get("mqttQos"), 0)
        if qos not in {0, 1, 2}:
            messages.append({"level": "bad", "text": "QoS 只能是 0、1、2。"})
    if generate_ds and protocols["ds"] == "iec104":
        validate_port(config.get("ds104PortStart", 2590), "104转发起始端口", messages)
        validate_host(config.get("ds104Host", ""), "104转发IP", messages)

    manual = parse_manual_templates(config.get("manualTemplates", ""))
    rules = parse_tag_rules(config.get("tagParamRules", ""))
    plan, plan_msgs = build_plan(config, devices, templates, manual)
    messages.extend(plan_msgs)
    total_tags = sum(p["channelTags"] for p in plan)
    if total_tags > 250000:
        messages.append({"level": "warn", "text": f"预计生成 {total_tags} 个点位，浏览器下载和采集服务导入都可能较慢。"})
    if any(m["level"] == "bad" for m in messages):
        return {"ok": False, "messages": messages, "plan": plan, "xml": "", "summary": summary(plan)}

    plugin = str(config.get("pluginName") or "TN_SIMULATOR").strip()
    device_name = str(config.get("deviceName") or "D1").strip()
    io104_host = str(config.get("io104Host") or "127.0.0.1").strip()
    io104_port_start = to_int(config.get("io104PortStart"), 2404)
    output_mode = str(config.get("outputMode") or "full")
    root_ver = str(config.get("rootVer") or "1")
    ds_points = ds_point_config(devices)
    ds_sizes = ds_group_size_config(config, devices)

    ds_groups: Dict[str, Dict[str, Any]] = {}
    ds_order: List[str] = []
    type_ordinals: Dict[str, int] = {}
    io104_index = 0
    io: List[str] = ["<io>"]
    gateway_eq_corridors: List[Dict[str, Any]] = []

    for ch in plan:
        use_104 = use_104_for_type(config, ch["type"])
        channel_plugin = "ELE_IEC_104" if use_104 else plugin
        s_count = "4" if use_104 else "3"
        io.append(f'  <channel s_count="{s_count}" plug_type="">')
        io.append(f'    <cnfg name="{esc(ch["channelName"])}" desc="{esc(ch["channelDesc"])}" plugin="{esc(channel_plugin)}">')
        if use_104:
            io.append(f'      <port v0="1" v1="{esc(io104_host)}" v2="{io104_port_start + io104_index}" v3="" />')
            io104_index += 1
        else:
            io.append('      <port v0="4" />')
        io.append("      <pars />")
        io.append("    </cnfg>")
        io.append("    <devices>")

        business_no = ch["startNo"]
        desc = f'{ch["prefix"]}{business_no}'
        tags = get_tags(ch["type"], ch["pointsPerDevice"], config, templates, manual, rules, ds_points)
        counters = {"yx": 1, "yc": 16385}
        type_ordinals[ch["type"]] = type_ordinals.get(ch["type"], 0) + 1
        ordinal = type_ordinals[ch["type"]]
        gateway_points: List[Dict[str, Any]] = [gateway_device_status_point()]
        io.append("      <device>")
        io.append(f'        <cnfg name="{esc(device_name)}" desc="{esc(desc)}" temp="" ip="" port="">')
        io.append('          <o fd="1" fd1="5" fd2="120" fd3="0" fd4="0" fd5="30" />')
        if use_104:
            io.extend(build_104_collect_pars())
        else:
            io.append("          <pars />")
        io.append("        </cnfg>")
        io.append("        <tags>")
        for tg in tags:
            out_tag = normalize_104_tag(tg, counters) if use_104 else tg
            gateway_points.append(gateway_collect_point(out_tag))
            io.append(f"            {tag_xml(out_tag)}")
            cat = ds_category(ch["type"], out_tag.get("d", ""))
            group_no = ds_group_no(ch["type"], cat, business_no, ordinal)
            sub_device = ds_sub_device(cat, desc, ordinal)
            group_key = f'{cat}|{group_no}|{ch["channelName"]}|{device_name}'
            if group_key not in ds_groups:
                ds_groups[group_key] = {"category": cat, "groupNo": group_no, "refs": [], "dsGroupSize": ds_sizes.get(cat, ch.get("dsGroupSize", 1))}
                ds_order.append(group_key)
            ds_groups[group_key]["refs"].append({"name": f'{ch["channelName"]}.{device_name}.{out_tag.get("n", "")}', "desc": f'{desc} {out_tag.get("d", "")}', "unit": out_tag.get("u", ""), "link": f'io.{ch["channelName"]}.{device_name}.{out_tag.get("n", "")}', "subDevice": sub_device, "tagDesc": out_tag.get("d", "")})
        io.append("        </tags>")
        io.append("      </device>")
        io.append("    </devices>")
        io.append("  </channel>")
        gateway_eq_corridors.append({
            "name": ch["channelName"],
            "alias_name": ch["channelDesc"],
            "used": True,
            "type": "simulate_enhanced",
            "class_name": "SimulateEnhancedConnector",
            "server": {
                "disconnected_option": 0,
                "devices": [{
                    "refresh_interval": 1.0,
                    "point_table": gateway_points,
                    "deviceName": device_name,
                    "alias_name": "设备01",
                    "used": True,
                }],
            },
        })
    io.append("</io>")

    io_xml = "\n".join(io)
    if output_mode == "io":
        xml = io_xml
    else:
        ds_xml = build_ds(config, [ds_groups[k] for k in ds_order], max(1, to_int(config.get("maxDsTags"), 6000)), protocols)
        xml = "\n".join(['<?xml version="1.0" encoding="UTF-8"?>', f'<root ver="{esc(root_ver)}" com="1" write1="3000" write2="30" write3="60" write4="0" write5="0" write6="0" save_period="0" xml_bin="0">', io_xml, ds_xml, "</root>"])
    if plan:
        messages.insert(0, {"level": "ok", "text": f"已生成 {len(plan)} 个采集通道，点位总数 {total_tags}。"})
    gateway_project = build_gateway_project(config, gateway_eq_corridors, [ds_groups[k] for k in ds_order], max(1, to_int(config.get("maxDsTags"), 6000)))
    gateway_json = json.dumps(gateway_project, ensure_ascii=False, indent=2)
    project_format = str(config.get("projectFormat") or "ironbull")
    if project_format == "gateway":
        messages.insert(0, {"level": "ok", "text": "已生成自研网关 tb_gateway.json 工程格式。"})
        artifact = gateway_json
        artifact_name = "tb_gateway.generated.json"
        artifact_mime = "application/json;charset=utf-8"
    else:
        artifact = xml
        artifact_name = "db.generated.xml"
        artifact_mime = "text/xml;charset=utf-8"
    return {"ok": True, "messages": messages, "plan": plan, "xml": xml, "gateway": gateway_json, "artifact": artifact, "artifactName": artifact_name, "artifactMime": artifact_mime, "summary": summary(plan)}


def type_code(desc: str) -> str:
    if re.search(r"_YT$", desc or "", re.I):
        return "4"
    if re.search(r"_YX$", desc or "", re.I):
        return "2"
    return "1"


def build_104_ds_pars() -> List[str]:
    pairs = [("address", "1"), ("reson_len", "2"), ("address_len", "2"), ("body_len", "3"), ("ack_times", "8"), ("check_time", "3000"), ("accept_check_time", "NO"), ("auto_total", "0"), ("no_start", "NO"), ("delay", "50"), ("total_mode", "NO"), ("double_yk", "NO"), ("reason", "0")]
    return ["      <pars>"] + [f'        <p name="{n}" value="{v}" />' for n, v in pairs] + ["      </pars>"]


def period_number_text(value: Any, default: str) -> str:
    """Return the user's period value as text.

    The IronBull MQTT parameters use 0 as a valid configured value in some
    deployments, so 0 must be preserved instead of falling back to defaults.
    Empty or non-numeric values still use the provided default.
    """
    text = str(value if value is not None else "").strip()
    if not text:
        return default
    try:
        number = float(text)
    except ValueError:
        return default
    if number < 0:
        return default
    return text


def normalize_period_rules(config: Dict[str, Any]) -> List[Dict[str, str]]:
    raw = config.get("dsPeriodRules")
    if not isinstance(raw, list) or not raw:
        raw = [{"match": "*", "changePeriod": "1", "pubTimer": "300", "note": "默认规则"}]
    rules: List[Dict[str, str]] = []
    for item in raw:
        if not isinstance(item, dict):
            continue
        match = str(item.get("match") or "*").strip().lower()
        if not match:
            continue

        # v12 修正映射：
        #   页面“变化周期”写入 <p name="change" value="周期"/>，允许 0 或正数；例如 3 表示 3 秒一变化。
        #   页面“全部数据发布周期”写入 <p name="pub_timer" value="周期"/>，同样允许 0 或正数。
        #   time 参数保持原有默认值，不再把“全部数据发布周期”误写到 time。
        # 兼容旧配置：changeValue/change/changeEnable 会作为变化周期保留；fullPeriod 继续作为 pub_timer。
        change_raw = item.get("changePeriod", item.get("changeValue", item.get("change", item.get("changeEnable", "1"))))
        change_period = period_number_text(change_raw, "1")

        pub_raw = item.get("pubTimer", item.get("pub_timer", item.get("fullPeriod", "300")))
        pub_timer = period_number_text(pub_raw, "300")

        rules.append({"match": match, "changePeriod": change_period, "pubTimer": pub_timer})
    return rules or [{"match": "*", "changePeriod": "1", "pubTimer": "300"}]


def resolve_ds_periods(config: Dict[str, Any], category: str, channel_name: str, channel_desc: str) -> Dict[str, str]:
    # 后面的规则优先级更高；支持 *、类型、转发通道名 C1、通道描述 bms62-66。
    targets = {"*", str(category or "").lower(), str(channel_name or "").lower(), str(channel_desc or "").lower()}
    selected = {"changePeriod": "1", "pubTimer": "300"}
    for rule in normalize_period_rules(config):
        if rule["match"] in targets:
            selected = {"changePeriod": rule["changePeriod"], "pubTimer": rule["pubTimer"]}
    return selected


def build_mqtt_pars(config: Dict[str, Any], credential: str, periods: Dict[str, str] | None = None) -> List[str]:
    periods = periods or {"changePeriod": "1", "pubTimer": "300"}
    mqtt_time = str(config.get("mqttTime") or "60")
    if to_int(mqtt_time, 0) <= 0:
        mqtt_time = "60"
    pairs = [("ip", config.get("mqttHost", "127.0.0.1")), ("port", config.get("mqttPort", "1883")), ("clientid", credential), ("user", credential), ("pwd", credential), ("sn", config.get("mqttSn", "TN001")), ("qos", config.get("mqttQos", "0")), ("pub", config.get("mqttPub", "v1/devices/me/telemetry")), ("sub", config.get("mqttSub", "v1/devices/me/rpc/request/+")), ("pub2", config.get("mqttPub2", "pub2")), ("change", periods.get("changePeriod", "1")), ("pub_timer", periods.get("pubTimer", "300")), ("cmd", "30"), ("log", "NO"), ("time", mqtt_time), ("ifcache", "NO"), ("hispath", "/mnt/sd/"), ("capacity", "10"), ("sendhis", "5")]
    return ["      <pars>"] + [f'        <p name="{n}" value="{esc(v)}" />' for n, v in pairs] + ["      </pars>"]


def build_ds(config: Dict[str, Any], groups: List[Dict[str, Any]], max_ds_tags: int, protocols: Dict[str, str] | None = None) -> str:
    if str(config.get("generateDs", "yes")) != "yes":
        return "<ds/>"
    protocols = protocols or resolve_protocols(config)
    is_104 = protocols["ds"] == "iec104"
    ds_plugin = "ELE_IEC_104" if is_104 else str(config.get("dsPluginName") or "MQTT_DZ_XJX")
    ds_desc = str(config.get("dsChannelDesc") or "forward")
    ds_limit = max(1, max_ds_tags)
    lines = ["<ds>"]
    channel_idx = 1
    counters = {"yx": 1, "yc": 16385, "yt": 25089}
    credential_counters: Dict[str, int] = {}

    if not groups:
        lines.append(f'  <channel s_count="{"5" if is_104 else "3"}" plug_type="">')
        lines.append(f'    <cnfg name="C1" desc="{esc(ds_desc)}1" plugin="{esc(ds_plugin)}">')
        if is_104:
            lines.append(f'      <port v0="2" v1="{esc(config.get("ds104Host") or "127.0.0.1")}" v2="{to_int(config.get("ds104PortStart"), 2590)}" v3="" />')
            lines.extend(build_104_ds_pars())
        else:
            lines.append('      <port v0="4" />')
            lines.append('      <pars />')
        lines.extend(["    </cnfg>", "    <tags />", "  </channel>", "</ds>"])
        return "\n".join(lines)

    categories = []
    for group in groups:
        cat = str(group.get("category") or "dev")
        if cat not in categories:
            categories.append(cat)

    for category in categories:
        cat_groups = [g for g in groups if str(g.get("category") or "dev") == category]
        category_group_count = len(cat_groups)
        bucket: List[Dict[str, Any]] = []
        bucket_tags = 0
        bucket_group_size = 0

        def flush():
            nonlocal bucket, bucket_tags, bucket_group_size, channel_idx
            if not bucket:
                return
            first_no = bucket[0].get("groupNo", 1)
            last_no = bucket[-1].get("groupNo", first_no)
            single_category_device = category_group_count == 1 and first_no == last_no
            # 只有一个该类型设备时，转发通道描述不追加序号。
            # 例如 CL 只有 1 个时，desc="cl"，而不是 "cl1"。
            if single_category_device:
                channel_desc = category
            else:
                channel_desc = f"{category}{first_no}-{last_no}" if first_no != last_no else f"{category}{first_no}"
            refs = []
            for group in bucket:
                refs.extend(group.get("refs", []))
            lines.append(f'  <channel s_count="{"5" if is_104 else "3"}" plug_type="">')
            lines.append(f'    <cnfg name="C{channel_idx}" desc="{esc(channel_desc)}" plugin="{esc(ds_plugin)}">')
            if is_104:
                lines.append(f'      <port v0="2" v1="{esc(config.get("ds104Host") or "127.0.0.1")}" v2="{to_int(config.get("ds104PortStart"), 2590) + channel_idx - 1}" v3="" />')
                lines.extend(build_104_ds_pars())
            else:
                credential_counters[category] = credential_counters.get(category, 0) + 1
                cred_prefix = str(config.get("mqttCredentialPrefix") or "client").rstrip("-")
                # 只有一个该类型设备时，MQTT clientid/user/pwd 不追加 z1。
                # 例如 CL 只有 1 个时，凭据为 jd-cl，而不是 jd-clz1。
                if single_category_device:
                    cred = f"{cred_prefix}-{category}"
                else:
                    cred = f"{cred_prefix}-{category}z{credential_counters[category]}"
                periods = resolve_ds_periods(config, category, f"C{channel_idx}", channel_desc)
                lines.append('      <port v0="4" />')
                lines.extend(build_mqtt_pars(config, cred, periods))
            lines.append("    </cnfg>")
            lines.append("    <tags>")
            for ref in refs:
                if is_104:
                    tc = type_code(ref.get("tagDesc", ""))
                    key = "yx" if tc == "2" else "yt" if tc == "4" else "yc"
                    addr = counters[key]
                    counters[key] += 1
                    lines.append(f'      <t v="1" n="{esc(ref["name"])}" d="{esc(ref["desc"])}" r="0" p="1000" u="{esc(ref["unit"])}" l="{esc(ref["link"])}" s0="{tc}" s1="{addr}" s2="2" s3="0" s4="0" />')
                else:
                    lines.append(f'      <t v="1" n="{esc(ref["name"])}" d="{esc(ref["desc"])}" r="0" p="1000" u="{esc(ref["unit"])}" l="{esc(ref["link"])}" s0="{esc(ref["subDevice"])}" s1="" s2="1" />')
            lines.append("    </tags>")
            lines.append("  </channel>")
            channel_idx += 1
            bucket = []
            bucket_tags = 0
            bucket_group_size = 0

        for group in cat_groups:
            refs = group.get("refs", [])
            configured_group_size = max(1, to_int(group.get("dsGroupSize"), 1))
            max_by_tags = max(1, ds_limit // max(1, len(refs)))
            group_size = min(configured_group_size, max_by_tags)
            if bucket and (bucket_tags + len(refs) > ds_limit or len(bucket) >= bucket_group_size or group_size != bucket_group_size):
                flush()
            bucket_group_size = group_size
            bucket.append(group)
            bucket_tags += len(refs)
            if bucket_tags >= ds_limit or len(bucket) >= bucket_group_size:
                flush()
        flush()

    lines.append("</ds>")
    return "\n".join(lines)


def summary(plan: List[Dict[str, Any]]) -> Dict[str, int]:
    return {"totalDevices": sum(p.get("deviceCount", 0) for p in plan), "totalTags": sum(p.get("channelTags", 0) for p in plan), "totalChannels": len(plan), "maxChannelTags": max([p.get("channelTags", 0) for p in plan] or [0])}
