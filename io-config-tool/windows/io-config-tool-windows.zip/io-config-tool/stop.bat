@echo off
setlocal
cd /d "%~dp0"
set "ARGS=%*"
where python >nul 2>nul
if %errorlevel%==0 (
  python launcher.py stop %ARGS%
  set "RC=%errorlevel%"
) else (
  where py >nul 2>nul
  if %errorlevel%==0 (
    py -3 launcher.py stop %ARGS%
    set "RC=%errorlevel%"
  ) else (
    echo Python was not found. Please install Python 3 or add it to PATH.
    set "RC=1"
  )
)
echo.
pause
exit /b %RC%
