from __future__ import annotations

import json
import os
import threading
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse, parse_qs
from uuid import uuid4
import shutil
from datetime import datetime
import workbench as w

from gateway_generator import DEFAULT_CONFIG, DEFAULT_TYPES, generate_package, plan_allocation

BASE = Path(__file__).resolve().parent
PORT = int(os.environ.get("PORT", "18767"))
HOST = os.environ.get("HOST", "127.0.0.1")
DATA_DIR = BASE / "data"
DATA_DIR.mkdir(exist_ok=True)
PID_FILE = DATA_DIR / "gateway-config-tool.pid"
PACKAGE_FILE = DATA_DIR / "gateway-projects.zip"
JOBS = {}
LOCK = threading.Lock()


def run_job(job_id, payload):
    def progress(done, total):
        with LOCK:
            JOBS[job_id].update(done=done, total=total)
            w.write_job(job_id, JOBS[job_id])
    try:
        result = w.generate_run(payload, progress, job_id)
        with LOCK:
            JOBS[job_id].update(state='complete', result=result)
            w.write_job(job_id, JOBS[job_id])
    except Exception as exc:
        with LOCK:
            JOBS[job_id].update(state='failed', error=str(exc))
            w.write_job(job_id, JOBS[job_id])


class Handler(SimpleHTTPRequestHandler):
    server_version = "GatewayWorkbench/2.1"

    def translate_path(self, path: str) -> str:
        path = urlparse(path).path
        if path == "/":
            return str(BASE / "templates" / "index.html")
        if path.startswith("/static/"):
            candidate = (BASE / path.lstrip('/')).resolve()
            if candidate.is_relative_to(BASE / 'static'):
                return str(candidate)
            return str(BASE / 'static' / 'not-found')
        return str(BASE / "templates" / "index.html")

    def send_json(self, obj: dict, code: int = 200) -> None:
        data = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def read_json(self) -> dict:
        if self.headers.get_content_type() != 'application/json':
            raise ValueError('请求必须使用 application/json')
        origin = self.headers.get('Origin')
        if origin and origin != 'http://' + self.headers.get('Host', ''):
            raise ValueError('不接受跨站配置请求')
        length = int(self.headers.get("Content-Length", "0"))
        if length <= 0:
            return {}
        if length > 2000000:
            raise ValueError('配置文件超过2MB上限')
        return json.loads(self.rfile.read(length).decode("utf-8"))

    def do_GET(self) -> None:
        parsed = urlparse(self.path)
        query = parse_qs(parsed.query)
        if parsed.path.startswith('/api/v2/'):
            try:
                route = parsed.path.rsplit('/', 1)[-1]
                if route == 'defaults':
                    return self.send_json({'ok': True, 'name': '小规模验证方案',
                        'config': {**w.DEFAULTS, 'platformDevicePrefix': 'jd', 'forwardMode': 'aggregate'},
                        'types': [{**r, 'total': 2, 'projects': [], 'changeRate': 20} for r in DEFAULT_TYPES]})
                if route == 'preset':
                    return self.send_json({'ok': True, 'name': '520万点性能测试方案',
                        'config': {**w.DEFAULTS, 'platformDevicePrefix': 'jd', 'forwardMode': 'aggregate'},
                        'types': [{**r, 'changeRate': 20} for r in DEFAULT_TYPES]})
                if route in ('schemes', 'runs'):
                    items = w.listing(route)
                    if route == 'schemes':
                        items = [{k:v for k,v in item.items() if k not in ('config','types')} for item in items]
                    return self.send_json({'ok': True, 'items': items})
                item_id = w.safe_id(query.get('id', [''])[0])
                if route == 'job':
                    with LOCK:
                        job = dict(JOBS[item_id]) if item_id in JOBS else w.read_job(item_id)
                    return self.send_json({'ok': True, **job})
                if route in ('scheme', 'snapshot'):
                    path = DATA_DIR/'schemes'/(item_id+'.json') if route=='scheme' else DATA_DIR/'runs'/item_id/'snapshot.json'
                    return self.send_json({'ok': True, **json.loads(path.read_text(encoding='utf-8'))})
                if route == 'download':
                    folder = DATA_DIR/'runs'/item_id
                    if not (folder/'record.json').is_file():
                        raise ValueError('工程尚未完成校验')
                    if not json.loads((folder/'record.json').read_text(encoding='utf-8')).get('passed'):
                        raise ValueError('工程校验未通过')
                    path = folder/'gateway-projects.zip'
                    self.send_response(200)
                    self.send_header('Content-Type', 'application/zip')
                    self.send_header('Content-Length', str(path.stat().st_size))
                    self.send_header('Content-Disposition', f'attachment; filename="gateway-{item_id[:8]}.zip"')
                    self.end_headers()
                    with path.open('rb') as stream:
                        shutil.copyfileobj(stream, self.wfile)
                    return
                raise ValueError('未知接口')
            except Exception as exc:
                return self.send_json({'ok': False, 'message': str(exc)}, 400)
        if parsed.path == "/api/health":
            return self.send_json({"ok": True, "name": "gateway-config-tool", "version": w.VERSION,
                                   "directory": str(BASE), "port": PORT})
        if parsed.path == "/api/defaults":
            return self.send_json({"ok": True, "config": DEFAULT_CONFIG, "types": DEFAULT_TYPES})
        if parsed.path == "/api/download":
            return self.send_json({'ok': False, 'message': '请从生成记录下载已校验工程包'}, 400)
        return super().do_GET()

    def do_POST(self) -> None:
        parsed = urlparse(self.path)
        try:
            if parsed.path.startswith('/api/v2/'):
                payload = self.read_json()
                route = parsed.path.rsplit('/',1)[-1]
                if route == 'plan':
                    return self.send_json(w.prepare(payload)[0])
                if route == 'normalize':
                    config, types = w.normalize(payload)
                    return self.send_json({'ok': True, 'name': payload.get('name', ''), 'config': config, 'types': types})
                if route == 'save':
                    return self.send_json(w.save_scheme(payload))
                if route == 'delete-scheme':
                    return self.send_json(w.delete_scheme(payload))
                if route == 'generate':
                    with LOCK:
                        if any(j['state']=='running' for j in JOBS.values()):
                            raise ValueError('已有生成任务正在运行')
                        job_id = uuid4().hex
                        JOBS[job_id] = {'state':'running', 'done':0, 'total':0,
                                        'name': str(payload.get('name', '未命名方案'))[:100],
                                        'started': datetime.now().isoformat(timespec='seconds')}
                        w.write_job(job_id, JOBS[job_id])
                    threading.Thread(target=run_job, args=(job_id,payload), daemon=True).start()
                    return self.send_json({'ok':True, 'id':job_id})
                raise ValueError('未知接口')
            if parsed.path == "/api/generate":
                raise ValueError('请使用新版计算与校验流程')
            if parsed.path == "/api/plan":
                raise ValueError('请使用新版计算与校验流程')
            if parsed.path == "/api/shutdown":
                self.read_json()
                if any(j['state'] == 'running' for j in JOBS.values()):
                    raise ValueError('正在生成，请完成后再停止服务')
                self.send_json({"ok": True, "message": "服务正在停止。"})
                threading.Thread(target=self.server.shutdown, daemon=True).start()
                return
            return self.send_json({"ok": False, "message": "未知接口。"}, 404)
        except Exception as exc:
            return self.send_json({"ok": False, "message": str(exc)}, 400 if isinstance(exc, (ValueError, KeyError)) else 500)


def main() -> None:
    for path in (DATA_DIR / 'jobs').glob('*.json'):
        w.write_job(path.stem, w.read_job(path.stem))
    PID_FILE.write_text(str(os.getpid()), encoding="utf-8")
    httpd = ThreadingHTTPServer((HOST, PORT), Handler)
    print(f"网关工程生成工具已启动: http://{HOST}:{PORT}")
    print(f"PID: {os.getpid()}")
    try:
        httpd.serve_forever()
    finally:
        try:
            PID_FILE.unlink(missing_ok=True)
        except Exception:
            pass
        print("服务已停止。")


if __name__ == "__main__":
    main()
