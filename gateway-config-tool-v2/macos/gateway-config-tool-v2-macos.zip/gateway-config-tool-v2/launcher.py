from __future__ import annotations

import argparse
import json
import os
import signal
import socket
import subprocess
import sys
import time
import urllib.request
from pathlib import Path

BASE = Path(__file__).resolve().parent
DATA = BASE / "data"
PID_FILE = DATA / "gateway-config-tool.pid"
LOG_FILE = DATA / "server.log"
ERR_FILE = DATA / "server.err.log"


def ensure_data() -> None:
    DATA.mkdir(exist_ok=True)


def read_pid() -> int | None:
    try:
        text = PID_FILE.read_text(encoding="utf-8").strip()
        return int(text) if text else None
    except Exception:
        return None


def is_pid_running(pid: int | None) -> bool:
    if not pid or pid <= 0:
        return False
    try:
        if os.name == "nt":
            result = subprocess.run(["tasklist", "/FI", f"PID eq {pid}", "/FO", "CSV", "/NH"], stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, text=True, encoding="utf-8", errors="ignore")
            return str(pid) in result.stdout
        os.kill(pid, 0)
        return True
    except Exception:
        return False


def url(port: int, host: str = "127.0.0.1") -> str:
    return f"http://{host}:{port}"


def health(port: int, host: str = "127.0.0.1", timeout: float = 1.0) -> bool:
    try:
        with urllib.request.urlopen(f"{url(port, host)}/api/health", timeout=timeout) as resp:
            value = json.load(resp)
            return resp.status == 200 and value.get('directory') == str(BASE)
    except Exception:
        return False


def port_in_use(port: int, host: str = "127.0.0.1") -> bool:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.settimeout(0.5)
        return sock.connect_ex((host, port)) == 0


def tail(path: Path, max_chars: int = 3000) -> str:
    if not path.exists():
        return ""
    return path.read_text(encoding="utf-8", errors="ignore")[-max_chars:]


def wait_for_health(port: int, host: str, seconds: int) -> bool:
    deadline = time.time() + seconds
    while time.time() < deadline:
        if health(port, host):
            return True
        time.sleep(0.5)
    return False


def start(args) -> int:
    ensure_data()
    port = int(args.port or os.environ.get("PORT", "18767"))
    host = args.host or os.environ.get("HOST", "127.0.0.1")
    pid = read_pid()
    if health(port, host):
        print(f"gateway-config-tool is already running. Open: {url(port, host)}")
        print(f"PID: {pid}")
        return 0
    if port_in_use(port, host):
        print(f"Port {port} is already in use by another process.")
        return 2
    env = os.environ.copy()
    env["PORT"] = str(port)
    env["HOST"] = host
    LOG_FILE.write_text("", encoding="utf-8")
    ERR_FILE.write_text("", encoding="utf-8")
    kwargs = {
        "cwd": str(BASE),
        "env": env,
        "stdout": LOG_FILE.open("ab"),
        "stderr": ERR_FILE.open("ab"),
        "stdin": subprocess.DEVNULL,
    }
    if os.name == "nt":
        kwargs["creationflags"] = subprocess.CREATE_NEW_PROCESS_GROUP | subprocess.DETACHED_PROCESS
    else:
        kwargs["start_new_session"] = True
    print(f"Starting gateway-config-tool on port {port} ...")
    proc = subprocess.Popen([sys.executable, str(BASE / "app.py")], **kwargs)
    time.sleep(0.5)
    if proc.poll() is not None:
        print("Start failed.")
        print(tail(ERR_FILE) or tail(LOG_FILE))
        return 1
    if wait_for_health(port, host, args.wait):
        print(f"Started successfully. Open: {url(port, host)}")
        print(f"PID: {proc.pid}")
        print(f"Log file: {LOG_FILE}")
        return 0
    print(f"Start command was issued, but health check did not pass. Try: {url(port, host)}")
    print(tail(ERR_FILE) or tail(LOG_FILE))
    return 3


def stop(args) -> int:
    ensure_data()
    port = int(args.port or os.environ.get("PORT", "18767"))
    host = args.host or os.environ.get("HOST", "127.0.0.1")
    stopped = False
    if health(port, host):
        try:
            req = urllib.request.Request(f"{url(port, host)}/api/shutdown", method="POST", data=b"{}", headers={"Content-Type": "application/json"})
            urllib.request.urlopen(req, timeout=2).read()
            stopped = True
            time.sleep(1)
        except Exception as exc:
            print('Stop refused:', exc)
            return 1
    pid = read_pid()
    if is_pid_running(pid) and not stopped:
        print('Service is not responding. No process was killed.')
        return 1
    try:
        PID_FILE.unlink(missing_ok=True)
    except Exception:
        pass
    print("Stopped gateway-config-tool." if stopped else "gateway-config-tool was not running.")
    return 0


def status(args) -> int:
    ensure_data()
    port = int(args.port or os.environ.get("PORT", "18767"))
    host = args.host or os.environ.get("HOST", "127.0.0.1")
    pid = read_pid()
    ok = health(port, host)
    print(f"URL: {url(port, host)}")
    print(f"PID file: {pid if pid else 'not found'}")
    print(f"PID running: {is_pid_running(pid)}")
    print(f"Health check: {'OK' if ok else 'FAILED'}")
    print(f"Log file: {LOG_FILE}")
    print(f"Error log: {ERR_FILE}")
    if not ok:
        latest = tail(ERR_FILE) or tail(LOG_FILE)
        if latest:
            print(latest)
    return 0 if ok else 1


def main() -> int:
    parser = argparse.ArgumentParser(description="gateway-config-tool service manager")
    sub = parser.add_subparsers(dest="command", required=True)
    for name in ("start", "stop", "status"):
        item = sub.add_parser(name)
        item.add_argument("--port", type=int, default=None)
        item.add_argument("--host", default=None)
        if name == "start":
            item.add_argument("--wait", type=int, default=10)
    args = parser.parse_args()
    return {"start": start, "stop": stop, "status": status}[args.command](args)


if __name__ == "__main__":
    raise SystemExit(main())
