@echo off
setlocal
set PORT=18767
if not "%~1"=="" set PORT=%~1
py -3 "%~dp0launcher.py" stop --port %PORT%
